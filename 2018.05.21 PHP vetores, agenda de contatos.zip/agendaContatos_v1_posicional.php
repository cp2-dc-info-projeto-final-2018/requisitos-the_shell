<?php
	$listaContatos = [
		[ 'Ana Clara',
		  '+55 (21) 2222-2222',
		  'anaclara@example.net',
		  '01/02/1998' ],

		[ 'Ricardo Almeida',
		  '+351 (226) 837-125',
		  'ralmeida@example.net',
		  '27/09/1992' ],

		[ 'Dalva Santos',
		  '+258 (84) 629-4862',
		  'santos@example.net',
		  '16/11/1997' ]
	];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8"/>
	<title>Agenda de contatos</title>
	<link rel="stylesheet" type="text/css" href="agendaContatos.css"/>
</head>
<body>
	<h1>Agenda de contatos</h1>

	<?php foreach ($listaContatos as $contato) { ?>
		<div>
			<h2><?= $contato[0] ?></h2>
			<dl>
				<dt>Tel.</dt>
				<dd><?= $contato[1] ?></dd>

				<dt>E-mail</dt>
				<dd><a href="mailto:<?= $contato[2] ?>"><?= $contato[2] ?></a></dd>

				<dt>Aniversário</dt>
				<dd><?= $contato[3] ?></dd>
			</dl>
		</div>
	<?php } ?>
</body>
</html>