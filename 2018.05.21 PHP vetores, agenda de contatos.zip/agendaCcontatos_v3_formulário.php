<?php
	$listaContatos = [
		[ 'nome' => 'Ana Clara',
		  'tel' => '+55 (21) 2222-2222',
		  'email' => 'anaclara@example.net',
		  'dataNasc' => '01/02/1998' ],

		[ 'nome' => 'Ricardo Almeida',
		  'tel' => '+351 (226) 837-125',
		  'email' => 'ralmeida@example.net',
		  'dataNasc' => '27/09/1992' ],

		[ 'nome' => 'Dalva Santos',
		  'tel' => '+258 (84) 629-4862',
		  'email' => 'santos@example.net',
		  'dataNasc' => '16/11/1997' ]
	];


	// A variável `$_REQUEST` é uma variável definida automaticamente pelo PHP.
	// Ela armazena os dados enviados pelo usuário em formulários.
	// Para inspecionar conteúdo dessa variável, descomente a linha abaixo:
	// print_r($_REQUEST);

	if (! empty($_REQUEST)) {
		// CUIDADO!
		// Para manter o exemplo simples, não estamos fazendo nenhum tipo de
		// validação ou crítica dos dados recebidos pela rede. Isso, porém, é
		// EXTREMAMENTE PERIGOSO, e pode abrir várias brechas de segurança! Em
		// um sistema real, é necessário adicionar as validações (ex.: http://php.net/manual/book.filter.php).

		$novoContato = [
			'nome' => $_REQUEST['nome'],
			'tel' => $_REQUEST['tel'],
			'email' => $_REQUEST['email'],
			'dataNasc' => $_REQUEST['dataNasc']
		];

		$listaContatos[] = $novoContato;
	}


	// Extra - Ordena os contatos alfabeticamente:
	function comparaNomesContatos($contato1, $contato2) {
		return $contato1['nome'] <=> $contato2['nome'];
	}

	usort($listaContatos, 'comparaNomesContatos');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8"/>
	<title>Agenda de contatos</title>
	<link rel="stylesheet" type="text/css" href="agendaContatos.css"/>
</head>
<body>
	<h1>Agenda de contatos</h1>

	<?php foreach ($listaContatos as $contato) { ?>
		<div>
			<h2><?= $contato['nome'] ?></h2>
			<dl>
				<dt>Tel.</dt>
				<dd><?= $contato['tel'] ?></dd>

				<dt>E-mail</dt>
				<dd><a href="mailto:<?= $contato['email'] ?>"><?= $contato['email'] ?></a></dd>

				<dt>Aniversário</dt>
				<dd><?= $contato['dataNasc'] ?></dd>
			</dl>
		</div>
	<?php } ?>

	<h1>Adicionar contato</h1>
	<form method="POST">
		<label>Nome: <input name="nome" required type="text"/></label>
		<label>Tel.: <input name="tel" type="tel"/></label>
		<label>E-Mail: <input name="email" type="email"/></label>
		<label>Data Nasc.: <input name="dataNasc" type="date"/></label>
		<input type="submit" value="Adicionar"/>
	</form>
</body>
</html>