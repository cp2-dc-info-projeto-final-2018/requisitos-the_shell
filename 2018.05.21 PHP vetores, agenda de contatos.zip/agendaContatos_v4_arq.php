﻿<!--
	Nesta versão, nós persistimos os contatos adicionados na agenda em um arquivo CSV (_comma separated values_). Neste arquivo, cada linha representa um contato. Os campos de cada linha são separados por um caractere `;`.

	Usamos as funções `file_put_contents()` e `file()` do PHP para respectivamente salvar e ler os contatos de um arquivo, de forma a termos uma funcionalidade de persistência básica.

	A conversão entre os vetores que representam os contatos na memória e as linhas separadas por `;` do arquivo são feitas usando as funções `implode()` e `explode()` do PHP.
 -->
<?php
	const arq = 'agendaContatos.csv';

	// Salva novo contato no arquivo:
	if (!empty($_REQUEST))
	{
		$campos = [ $_REQUEST['nome'], $_REQUEST['tel'], $_REQUEST['email'], $_REQUEST['dataNasc'] ];
		$registro = implode("; ", $campos);

		file_put_contents(arq, $registro . PHP_EOL, FILE_APPEND | LOCK_EX);
	}

	$listaContatos = [];
	
	// Carrega lista de contatos do arquivo:
	if (is_file(arq)) {
		$linhas = file(arq);
		foreach($linhas as $l) {
			$campos = explode("; ", $l);
			$listaContatos[] = [
				'nome' => $campos[0],
				'tel' => $campos[1],
				'email' => $campos[2],
				'dataNasc' => $campos[3],
			];
		}
	}

	// Extra - Ordena os contatos alfabeticamente:
	function comparaNomesContatos($contato1, $contato2) {
		return $contato1['nome'] <=> $contato2['nome'];
	}
	usort($listaContatos, 'comparaNomesContatos');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8"/>
	<title>Agenda de contatos</title>
	<link rel="stylesheet" type="text/css" href="agendaContatos.css"/>
</head>
<body>
	<h1>Agenda de contatos</h1>

	<?php foreach ($listaContatos as $contato) { ?>
		<div>
			<h2><?= $contato['nome'] ?></h2>
			<dl>
				<dt>Tel.</dt>
				<dd><?= $contato['tel'] ?></dd>
				
				<dt>E-mail</dt>
				<dd><a href="mailto:<?= $contato['email'] ?>"><?= $contato['email'] ?></a></dd>
				
				<dt>Aniversário</dt>
				<dd><?= $contato['dataNasc'] ?></dd>
			</dl>
		</div>
	<?php } ?>
	
	<h1>Adicionar contato</h1>
	<form method="POST">
		<label>Nome: <input name="nome" required type="text"/></label>
		<label>Tel.: <input name="tel" type="tel"/></label>
		<label>E-Mail: <input name="email" type="email"/></label>
		<label>Data Nasc.: <input name="dataNasc" type="date"/></label>
		<input type="submit" value="Adicionar"/>
	</form>
</body>
</html>