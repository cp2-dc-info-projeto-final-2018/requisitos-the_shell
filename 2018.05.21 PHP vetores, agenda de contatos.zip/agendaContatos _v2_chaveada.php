<?php
	$listaContatos = [
		[ 'nome' => 'Ana Clara',
		  'tel' => '+55 (21) 2222-2222',
		  'email' => 'anaclara@example.net',
		  'dataNasc' => '01/02/1998' ],

		[ 'nome' => 'Ricardo Almeida',
		  'tel' => '+351 (226) 837-125',
		  'email' => 'ralmeida@example.net',
		  'dataNasc' => '27/09/1992' ],

		[ 'nome' => 'Dalva Santos',
		  'tel' => '+258 (84) 629-4862',
		  'email' => 'santos@example.net',
		  'dataNasc' => '16/11/1997' ]
	];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8"/>
	<title>Agenda de contatos</title>
	<link rel="stylesheet" type="text/css" href="agendaContatos.css"/>
</head>
<body>
	<h1>Agenda de contatos</h1>

	<?php foreach ($listaContatos as $contato) { ?>
		<div>
			<h2><?= $contato['nome'] ?></h2>
			<dl>
				<dt>Tel.</dt>
				<dd><?= $contato['tel'] ?></dd>

				<dt>E-mail</dt>
				<dd><a href="mailto:<?= $contato['email'] ?>"><?= $contato['email'] ?></a></dd>

				<dt>Aniversário</dt>
				<dd><?= $contato['dataNasc'] ?></dd>
			</dl>
		</div>
	<?php } ?>
</body>
</html>