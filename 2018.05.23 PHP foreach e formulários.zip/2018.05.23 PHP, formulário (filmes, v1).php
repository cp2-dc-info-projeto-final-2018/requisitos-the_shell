<?php
	function notaMedia($listaAvaliacoes)
	{
		$notas = array_column($listaAvaliacoes, 'nota');

		if (empty($notas))
			return null;
		else
			return array_sum($notas) / count($notas);
	}

	$listaAvaliacoes = [];

	// Registra nova avaliação caso o usuário tenha preenchido e enviado o formulário da página:
	if (!empty($_REQUEST))
	{
		$listaAvaliacoes[] = [
			'usuario' => htmlspecialchars(trim($_REQUEST['usuario'])),
			'nota' => $_REQUEST['nota'],
			'comentarios' => htmlspecialchars($_REQUEST['comentarios'])
		];
	}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8"/>
	<title>CP2MDB</title>
</head>
<body>
	<h1>CP2MDB</h1>

	<div style="float: right"><img src="https://upload.wikimedia.org/wikipedia/pt/1/10/CidadedeDeus.jpg" alt="Cartaz do filme"/></div>

	<h2>Cidade de Deus</h2>
	<p>
		Avaliações: <?= count($listaAvaliacoes) ?>
		<?php if (count($listaAvaliacoes) > 0) { ?>
			| ★ <strong><?= number_format(notaMedia($listaAvaliacoes), 1) ?> / 5.0</strong>
		<?php } ?>
	</p>


	<h3>Avalie</h3>
	<form method="POST">
		<label>Usuário: <input name="usuario" required type="text"/></label>

		<fieldset id="avaliacao_filme">
			<legend>Avaliação:</legend>
			<label><input name="nota" required type="radio" value="5"/>★★★★★</label><br/>
			<label><input name="nota" required type="radio" value="4"/>★★★★</label><br/>
			<label><input name="nota" required type="radio" value="3"/>★★★</label><br/>
			<label><input name="nota" required type="radio" value="2"/>★★</label><br/>
			<label><input name="nota" required type="radio" value="1"/>★</label><br/>
		</fieldset>

		<label>Comentários sobre o filme:<br/>
		<textarea name="comentarios" rows="6"></textarea><br/>
		</label>

		<input type="submit" value="Avaliar"/>
	</form>


	<h3>Avaliações dos usuários</h3>
	<?php foreach ($listaAvaliacoes as $avaliacao) { ?>
		<div>
			<p>
				<strong><?= $avaliacao['usuario'] ?></strong>
				(<?= str_repeat('★', $avaliacao['nota']) ?>)
			</p>
			<p><?= $avaliacao['comentarios'] ?></p>
		</div>
	<?php } ?>

	<?php if (empty($listaAvaliacoes)) { ?>
		<p>Nenhuma avaliação foi feita até agora. Seja o primeiro a avaliar esse filme!</p>
	<?php } ?>

</body>
</html>