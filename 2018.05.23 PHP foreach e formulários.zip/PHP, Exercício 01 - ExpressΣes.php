<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8"/>
	<title>PHP - Ex. 1: Expressões</title>
</head>
<body>
	<ul>
		<li>2 + 3 = <?= 2 + 3 ?></li>
		<li>3 - 5 = <?= 3 - 5 ?></li>
		<li>2<sup>32</sup> = <?= 2 ** 32 ?></li>
		<li>log<sub>2</sub> 2048 = <?= log(2048, 2); ?></li>
	</ul>
</body>
</html>