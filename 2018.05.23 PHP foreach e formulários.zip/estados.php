<?php
	$UFS = [ 'AC', 'AL', 'AP', 'AM', 'BA', 'CE',
	         'DF', 'ES', 'GO', 'MA', 'MT', 'MS',
	         'MG', 'PA', 'PB', 'PR', 'PE', 'PI',
	         'RJ', 'RN', 'RS', 'RO', 'RR', 'SC',
	         'SP', 'SE', 'TO' ];
?>
<!DOCTYPE html>
<html lang='pt-BR'>
<head>
	<meta charset='utf-8'/>
	<title>Exercício - Preenchimento de seleção de estados</title>
</head>
<body>
	<form>
		<label>
			UF:
			<select name="uf" required>

				<option disabled selected value="">UF</option>

				<!-- Opções geradas pelo PHP: -->
				<?php foreach ($UFS as $uf) { ?>
					<option value="<?= $uf ?>"><?= $uf ?></option>
				<?php } ?>

			</select>
		</label>
	</form>
</body>
</html>